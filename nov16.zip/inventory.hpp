#ifndef INVENTORY
#define INVENTORY
#include "global.hpp"
#include "Console.hpp"

class crafted_items{
public:
  string name;
  int durability;
  int dmg;
  crafted_items(string x, int y, int z){
    name = x.c_str();
    durability = y;
    dmg = z;
  }
  crafted_items(const crafted_items &item){
      name = item.name;
      durability = item.durability;
      dmg = item.dmg;
  }
};

class inventory{
public:
  static const int size = 8;
  int content[size] = {20};

  std::vector<crafted_items> craft_storage;
  std::vector<crafted_items> equipped_weapon;
  bool WeaponStatus(){
    if(equipped_weapon[0].durability <= 0){
      return false;
    }
    return true;
  }
  int weaponDmg(string weapon){
    if(weapon == "gun"){return 90;}
    else if (weapon == "knife"){return 12;}
    else if (weapon == "axe") {return 25;}
    else if (weapon == "slinger") {return 40;}
  }

  crafted_items getweapon(){
    crafted_items null("null",0,0);
    if(equipped_weapon.size()>0){
      return equipped_weapon[0];
    }
    else{
      return null;
    }
  }
  int getsize(){
    return size;
  }
  int getmoney(){
    return content[MONEY];
  }
  void showInv(){
    refresh();
    for (int i = 0; i < size; i++){
      move(10+2*i,10);
      clrtoeol();
      mvprintw(10+2*i,10,"%s = %d", resource_str(RESOURCES(i)).c_str() ,content[i]);
    }
  }
  void showCrafted(){
    erase();
    refresh();
    if(craft_storage.size()<1){
      mvprintw(10,10,"Crafted toolbox is empty. Press c to return to game");
    }
    else{
      mvprintw(10,10,"Press e to choose weapon to equip. Press c to return to game.");
      for (int i = 0; i < craft_storage.size(); i++){
        mvprintw(12+2*i, 10, "You have a %s (%i%%)", craft_storage[i].name.c_str(), craft_storage[i].durability);
      }
    }
    if(getweapon().name == "null"){
      mvprintw(0,0, "You have not equipped any weapons.");
    }
    else{
      mvprintw(0,0, "You are equipping %s (%i%%) as your weapon.", getweapon().name.c_str(), getweapon().durability);
    }
  }
  void addInv(const int &item){
    content[item]++;
  }
  void addInv(const int &item, int how_many){
    content[item]+=how_many;
  }
  bool checkKey(){
    if( content[KEY] > 0)  {return true;}
    else                   {return false;}
  }
  void removeKey(){
    content[KEY] -= 1;
  }

  void craft(const string &name){
    crafted_items Item(name.c_str(), 100, weaponDmg(name.c_str()));
    craft_storage.push_back(Item);
  }

  int checkCrafted(string item){
    for (int i = 0; i < craft_storage.size();i++){
      if(craft_storage[i].name == item){
        return i; //return the index of the first match
      }
    }
    return -1;
  }

  void equipWeapon(int index){
    crafted_items to_be_equipped = craft_storage[index];
    if(equipped_weapon.size() > 0){
      crafted_items previous = equipped_weapon[0];
      craft_storage.erase(craft_storage.begin()+ index);
      equipped_weapon.pop_back();

      craft_storage.push_back(previous);
      equipped_weapon.push_back(to_be_equipped);
    }
    else{//weapon == empty
      equipped_weapon.push_back(to_be_equipped);
      craft_storage.erase(craft_storage.begin()+ index);
    }
  }

  void craftingTable(Console &console){
    showInv();
    mvprintw(2,0,"Press q to return to game.");
    mvprintw(10, 50,"Press 1 to craft an axe (need 2 WOOD and 2 ROCK).");
    mvprintw(12, 50,"Press 2 to craft a knife (need 2 SILVER).");
    mvprintw(14, 50,"Press 3 to craft a slinger (need 1 ROCK and 1 WOOD)");
    mvprintw(16, 50,"Press 4 to craft a gun (need 3 CHEMCIALS, 2 GOLD, 2 SILVER, 2 PLASTIC)");
    int key = getch();
    while(key != Q){
      if(key == KEY_ONE){
        if( content[WOOD] >= 2 && content[ROCK] >= 2 ){
          craft("axe");
          content[WOOD]-=2;
          content[ROCK]-=2;
          console.draw_prompt(0,0,"You have crafted an axe!");
        }
        else{console.draw_prompt(0,0,"You do not have enough materials!");}
      }
      if(key == KEY_TWO){
        if(content[SILVER]>=2){
          craft("knife");
          content[SILVER]-=2;
          console.draw_prompt(0,0,"You have crafted a knife!");
        }
        else{console.draw_prompt(0,0,"You do not have enough materials!");}
      }
      if(key == KEY_THREE){
        if(content[WOOD]>=1&&content[ROCK]>=1){
          craft("slinger");
          content[WOOD]--;
          content[ROCK]--;
          console.draw_prompt(0,0,"You have crafted a slinger!");
        }
        else{console.draw_prompt(0,0,"You do not have enough materials!");}
      }
      if(key == KEY_FOUR){
        if(content[CHEMICALS]>=3 && content[GOLD]>=2 && content[SILVER]>=2 && content[PLASTIC]>=2){
          craft("gun");
          content[CHEMICALS]-=3;
          content[GOLD]-=2;
          content[SILVER]-=2;
          content[PLASTIC]-=2;
          console.draw_prompt(0,0,"You have crafted a gun!");
        }
        else{console.draw_prompt(0,0,"You do not have enough materials!");}
      }
      showInv();
      mvprintw(2,0,"Press q to return to game.");
      mvprintw(10, 50,"Press 1 to craft an axe (need 2 WOOD and 2 ROCK).");
      mvprintw(12, 50,"Press 2 to craft a knife (need 2 SILVER).");
      mvprintw(14, 50,"Press 3 to craft a slinger (need 1 ROCK and 1 WOOD)");
      mvprintw(16, 50,"Press 4 to craft a gun (need 3 CHEMCIALS, 2 GOLD, 2 SILVER, 2 PLASTIC)");
      key = getch();
    }
  }
};
#endif
