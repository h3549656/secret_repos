#ifndef GLOBAL
#define GLOBAL
#include <ctime>
#include <array>
#include <sstream>
#include <string.h>
#include <fstream>
#include <curses.h>
#include <vector>
#include <algorithm>
using namespace std;
#define KEY_ESC 27
#define KEY_ONE 49
#define KEY_TWO (KEY_ONE+1)
#define KEY_THREE (KEY_TWO+1)
#define KEY_FOUR (KEY_THREE+1)
#define KEY_SPACE 32
const int MAXX = 200;
const int MAXY = 100;
//set terminal dimension
const int console_width = 180;
const int console_height= 40;
const int header = 3;
//size of each sub room
const int level_width[5] = {35,55,55,70,80};
const int level_height[5] = {33,33,33,33,34};
//Global map level control
bool lv_completed[5] = {false,false,false,false,false};
int MapLevel = 0;
long oldseed;//For random number generation
enum STRUCTURE { ROAD=777, DOOR=148, ENEMY, CHEST=114, WALL = 324 , BOUNDARY, GOAL=186, RECOVER=230, GATE=0,
                  DOOR_KEY=1, GWOOD=267, GROCK=220, GPLASTIC, GDIAMOND=223 , GMONEY=207, GCHEMCIALS, MERCHANT, GWINDOW };
enum RESOURCES { KEY=0, WOOD, GOLD, SILVER, ROCK, PLASTIC, CHEMICALS, DIAMOND, MONEY };
enum GETCH {A=97,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z};
enum direction { NAN=0, NORTH, WEST, SOUTH, EAST };
string resource_str(RESOURCES resource){
    if      ( resource == KEY  )      { return "key"; }
    else if ( resource == WOOD )      { return "wood"; }
    else if ( resource == GOLD )      { return "gold"; }
    else if ( resource == SILVER )    { return "silver"; }
    else if ( resource == ROCK )      { return "rock"; }
    else if ( resource == PLASTIC )   { return "plastic"; }
    else if ( resource == DIAMOND )   { return "diamond"; }
    else if ( resource == CHEMICALS ) { return "chemical"; }
    else if ( resource == MONEY )     { return "money"; }
}
string int_to_str( int value ){
    stringstream ss;
    ss << value;
    return ss.str();
}
int RNG(int min , int max){
  time_t seed;
  seed = time(NULL) + oldseed;
  oldseed = seed;
  srand(seed);
  int n = max - min + 1;
  int i = rand() % n;
  if(i < 0){ i = -i;}
  return min + i;
}
int max(int a, int b){
  if( a > b ) {return a;}
  else        {return b;}
}
int min(int a, int b){
  if( a < b ) {return a;}
  else        {return b;}
}

#endif
