#include "global.hpp"
#include "Console.hpp"
#include "inventory.hpp"
#include "object.hpp"
#include "Map.hpp"
#include "saveload_control.hpp"

int main(){
  Console console = Console();
  Map map1;
  inventory inventory;
  Player player;
  object merchant;
  const int enemy_num = 4;
  enemy enemy_array[enemy_num];
  int key, out_key, turn = 0, hp, attack_flag = -1, *levelptr = &MapLevel;
  int playery,playerx,merchantx,merchanty;

  //menu and game save control
  while (key != KEY_SPACE){
    console.showMenu();
    key = getch();
    if (key == KEY_ESC){
      console.goodbye();
      console.quit();
      break;
    }
    if( key == KEY_SPACE ){//new game LEVEL 0
      NewGame(player, enemy_array, enemy_num, merchant, map1, "MAP0.txt");
      break;
    }
    if (key == KEY_TWO){//load presaved game
      if(LoadSave("MapSave.txt","PlayerSave.txt","EnemySave.txt",player, enemy_array, merchant, inventory, map1, MapLevel)){
        console.console_output = "Save loaded.";
        break;
      }
      else{
        console.draw_prompt(0,0,"Could not open save files. Either they do not exist or are corrupted. Please don't tamper with the filenames.\
        Try deleting the existing save(s) and resave again.");
        getch();
      }
    }
  }
  erase();
  refresh();

  display_all(console, map1, player, merchant, enemy_array, enemy_num);

  console.tutorial();
  while (console.quit_status() == false){
    //check if player dead or not
    mvprintw(level_height[MapLevel],0,"Game Presented By Joseph Ho Meng Chit and Leo Lee Man Yin.");
    if (player.gethp() <= 0){
      console.defeated();
      console.quit();
      break;
    }
    if(inventory.getweapon().name != "null"){
      if(!inventory.WeaponStatus()){
        inventory.equipped_weapon.clear();
        console.console_output = "Your equipped weapon has broken!!@.@";
      }
    }
    if(console.console_output != "")  {console.draw_prompt(0,0,console.console_output);}
    console.tutorial();
    console.draw_prompt(0,1,"Player HP = " + int_to_str(player.gethp()));
    console.draw_prompt(0,2,"Map Level " + int_to_str(*levelptr));
    turn++;
    //level progression
    if(lv_completed[MapLevel]){
      if(MapLevel == 4){
        console.wingame();
        break;
      }
      console.levelup();
      //switch to new level
      string mapsavefilename = "MAP"+int_to_str(*levelptr)+".txt";
      SaveGame("temp_map.txt","temp_player.txt","temp_enemy.txt",player,inventory,map1,MapLevel,enemy_array,enemy_num,merchant);
      LoadSave(mapsavefilename,"temp_player.txt","temp_enemy.txt",player, enemy_array, merchant, inventory, map1, MapLevel);

      random_spawn("R", map1, 5);
      random_spawn("W", map1, 5);
      random_spawn("C", map1, 12);
      random_spawn("m", map1, 7);

      npc_setup(enemy_array, enemy_num, merchant,RNG(5,level_width[MapLevel]-5),RNG(5,level_height[MapLevel]-5));
    }

    if( turn % 2 == 0 ){
      global_chase( player, enemy_array, enemy_num, map1 );
      for ( int i = 0; i < enemy_num; i++ ){
        if( enemy_array[i].attack(player,2) ){
          console.console_output = "You are being attacked!!!";
        }
      }
    }
    refresh();

    display_all(console, map1, player, merchant, enemy_array, enemy_num);

    key = getch();
    switch (key) {
      case M:
        erase();
        console.showMenu();
        out_key = getch();
        while (out_key != M){
          if(out_key == KEY_ESC){
            console.goodbye();
            console.quit();
            break;
          }
          if (out_key == KEY_ONE ){
            SaveGame("MapSave.txt","PlayerSave.txt","EnemySave.txt",player,inventory,map1,MapLevel,enemy_array,enemy_num,merchant);
            console.draw_prompt(0,0,"Game saved. Press any key to continue.");
            getch();
            break;
          }
          console.showMenu();
          out_key = getch();
        }
        erase();
        turn=0;
        refresh();
        break;
      case W:
        if(map1.checkSurrounding(player,NORTH) == ROAD && player.isOverlap(enemy_array, enemy_num,player.getx(), player.gety()-1)==0 ) {player.Move(NORTH);}
        break;
      case S:
        if(map1.checkSurrounding(player,SOUTH) == ROAD && player.isOverlap(enemy_array, enemy_num,player.getx(), player.gety()+1)==0) {player.Move(SOUTH);}
        break;
      case A:
        if(map1.checkSurrounding(player,WEST) == ROAD && player.isOverlap(enemy_array, enemy_num,player.getx()-1, player.gety())==0) {player.Move(WEST);}
        break;
      case D:
        if(map1.checkSurrounding(player,EAST) == ROAD && player.isOverlap(enemy_array, enemy_num,player.getx()+1, player.gety())==0) {player.Move(EAST);}
        break;
      case L:
        if(map1.interact(player, EAST, inventory, console)) {map1.wipe(player,EAST);}
        attack_flag = attack_enemy(player,enemy_array,enemy_num,EAST,inventory);
        if(attack_flag != -1 ){
          if(enemy_array[attack_flag].gethp() <=0 ){
              console.console_output = "You have defeated an enemy!!!!";
          }
          else{
            console.console_output = "You have attacked an enemy in EAST dir. Enemy hp = " + int_to_str(enemy_array[attack_flag].gethp());
          }
        }
        break;
      case K:
        if(map1.interact(player, SOUTH, inventory, console)) {map1.wipe(player,SOUTH);}
        attack_flag = attack_enemy(player,enemy_array,enemy_num,SOUTH,inventory);
        if(attack_flag != -1 ){
          if(enemy_array[attack_flag].gethp() <=0 ){
              console.console_output = "You have defeated an enemy!!!!";
          }
          else{
            console.console_output = "You have attacked an enemy in SOUTH dir. Enemy hp = " + int_to_str(enemy_array[attack_flag].gethp());
          }
        }
        break;
      case J:
        if(map1.interact(player, WEST, inventory, console)) {map1.wipe(player,WEST);}
        attack_flag = attack_enemy(player,enemy_array,enemy_num,WEST,inventory);
        if(attack_flag != -1 ){
          if(enemy_array[attack_flag].gethp() <=0 ){
              console.console_output = "You have defeated an enemy!!!!";
          }
          else{
            console.console_output = "You have attacked an enemy in WEST dir. Enemy hp = " + int_to_str(enemy_array[attack_flag].gethp());
          }
        }
        break;
      case I:
        if(map1.interact(player, NORTH, inventory, console)) {map1.wipe(player,NORTH);}
        attack_flag = attack_enemy(player,enemy_array,enemy_num,NORTH,inventory);
        if(attack_flag != -1 ){
          if(enemy_array[attack_flag].gethp() <=0 ){
              console.console_output = "You have defeated an enemy!!!!";
          }
          else{console.console_output = "You have attacked an enemy in NORTH dir. Enemy hp = " + int_to_str(enemy_array[attack_flag].gethp());}
        }
        break;
      case E:
        if(player.isProximity(merchant)){
          erase();
          merchant_shop(inventory);
          erase();
          turn = 0;
        }
        break;
      case B:
        erase();
        refresh();
        inventory.showInv();
        out_key = getch();
        while (out_key != B && out_key != KEY_ESC){
          inventory.showInv();
          out_key = getch();
        }
        erase();
        turn=0;
        break;
      case C:
      //  erase();
        //refresh();
        inventory.showCrafted();
        out_key = getch();
        while (out_key != C && out_key != KEY_ESC){
          if(out_key == E){
            if(inventory.craft_storage.size() >= 1){
              move(2,0);
              clrtoeol();
              mvprintw(2,0,"which weapons do you want to equip?");
              for(int i = 0;i < inventory.craft_storage.size();i++){
                mvprintw(4+i, 0, "%i) %s (%i%%)",i+1,inventory.craft_storage[i].name.c_str(),inventory.craft_storage[i].durability);
              }
              int equip = getch();
              if(KEY_ONE<=equip && equip <= KEY_ONE+inventory.craft_storage.size()){
                inventory.equipWeapon(equip - KEY_ONE);
              }
            }
            else{
              move(2,0);
              clrtoeol();
              mvprintw(2,0,"You have no weapons available.");
            }
          }
          inventory.showCrafted();
          out_key = getch();
        }
        erase();
        turn=0;
        break;
      case Q:
        erase();
        inventory.craftingTable(console);
        erase();
        turn=0;
        break;
      case P:
        erase();
        console.showkeybind();
        out_key = getch();
        while (out_key != P && out_key != KEY_ESC){
          console.showkeybind();
          out_key = getch();
        }
        erase();
        turn=0;
        break;
      refresh();
    }
  }
  return 0;
}
