#ifndef CONSOLE
#define CONSOLE
#include "global.hpp"
class Console{
private:
  bool _quit_flag;
  void Color_control(){
    string colorNames[] = {
      "black", "blue", "green", "cyan", "red", "magenta", "yellow", "white",
      "bright black", "bright blue", "bright green", "bright cyan", "bright red",
      "bright magenta", "bright yellow", "bright white"
    };
    ofstream color_log("color_log.txt");
    int color_code = 100;
    for (int foreground = 0; foreground < 16; foreground++){
      for (int background = 0; background < 16; background++){
        init_pair(color_code,foreground,background);
        color_log << "color code "<< color_code << " = " << colorNames[foreground] << "+" << colorNames[background] << '\n';
        color_code++;
      }
    }
  }
public:
  string console_output = "";
  Console(){
    startScreen();
    resize_term(console_height,console_width);
  }
  void startScreen(){
    initscr();
    raw();
    noecho();
    keypad( stdscr, TRUE );
    _quit_flag = false;
    start_color();
    Color_control();
  }
  void endScreen(){
    endwin();
  }

  void initColor(int color_pair){
    attron(COLOR_PAIR(color_pair));
  }

  void endColor(int color_pair){
    attroff(COLOR_PAIR(color_pair));
  }

  void draw(int x, int y, const string& symbol){
    mvprintw(y, 2*x, symbol.c_str());
  }
  void draw(int x, int y, const string& symbol, const int& pair){
    initColor(pair);
    mvprintw(y,2*x-1, " ");
    mvprintw(y, 2*x, symbol.c_str());
    endColor(pair);
  }
  void draw_interactables(int x, int y, const string& symbol, const int& pair){
    initColor(pair);
    mvprintw(y, 2*x, symbol.c_str());
    endColor(pair);
  }
  void draw_prompt(int x, int y, const string& symbol){
    move(y,x);
    clrtoeol();
    mvprintw(y, x, symbol.c_str());
  }
  void draw_bound(int level){
    for (int line = header; line <= level_height[level]-1 ; line++){
      mvprintw(line,0,"o");
      mvprintw(line,level_width[level]*2,"o");
    }
    for (int column = 1; column < level_width[level]+1; column+=2){
      mvprintw(header, column*2,"o");
      mvprintw(level_height[level]-1, column*2,"o");
    }
  }
  void quit(){
    _quit_flag = true;
  }
  bool quit_status(){
    return _quit_flag;
  }
  void showMenu(){
    erase();
    string list_of_lines[] = {"Welcome to Roguelike Crawler.", "Press Space to start new game",
    "Press 1 to save playing game if available.", "Press 2 to load from save (only at the start of the game).","Press Esc to quit the game."};
    int length = sizeof(list_of_lines)/sizeof(list_of_lines[0]);

    for(int i = 0; i < length; i++){
      mvprintw(2*i+10,console_width/3, list_of_lines[i].c_str());
    }
    refresh();
  }
  void console_prompt(){
    mvprintw(0,0, console_output.c_str());
  }
  void defeated(){
    erase();
    mvprintw(10,12,"You have been defeated.....-.-.....GAMEOVER.....");
    getch();
    endScreen();
  }
  void goodbye(){
    erase();
    mvprintw(10,12,"See you next time......(, . ,)");
    getch();
    endScreen();
  }
  void wingame(){
    erase();
    mvprintw(10,12,"Congrats! You have finished the final level!!!");
    mvprintw(12,12,"Credits to Joseph Ho Meng Chit and Leo Lee Man Yin from COMP2113 (_2020_S1)");
    getch();
    endScreen();
  }
  void levelup(){
    erase();
    mvprintw(10,12,"Level %i Completed. Press any key to proceed.", MapLevel);
    getch();
    MapLevel++;
    erase();
  }
  void tutorial(){
      mvprintw(level_height[MapLevel]+1,0,"Press p to show help.");
  }
  void showkeybind(){
    string list_of_keybind[] = {
    "w: move up", "a: move left", "s: move down", "d: move right",
    "b: view inventory", "m: menu", "c: view crafted items/equip weapons", "q: craft items",
    "i: interact with up", "k: interact with down", "l: interact with right", "j: interact with left",
    "e: interact with merchant"
    };
    string list_of_MapItems[] = {
      "M = merchant", "E = enemy", "# = wall", "C = chest with random resources", "R = rock", "W = wood",
      "D = diamond", "P = plastic", "G = goal; the destination you need to arrive at", "/ = door", "{ or } = gate",
      "m = money", "H = health recover", "K = key"
    };
    int length_keybind = sizeof(list_of_keybind)/sizeof(list_of_keybind[0]);
    int length_MapItems = sizeof(list_of_MapItems)/sizeof(list_of_MapItems[0]);
    mvprintw(0,0,"KEYBIND & MAP ITEMS");
    mvprintw(1,0,"Press p to return game.");
    for (int i = 0; i < length_keybind;i++){
      mvprintw(2*i+4,5, list_of_keybind[i].c_str());
    }
    for (int i = 0; i < length_MapItems; i++){
      mvprintw(2*i+4, 50, list_of_MapItems[i].c_str() );
    }

  }
};




#endif
